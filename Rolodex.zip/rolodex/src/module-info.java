module rolodex {
	requires org.junit.jupiter.api;
	requires junit;
}