package groceryStub;
import basics.SLL;
import basics.ShoppingCart;
import basics.SLL.Node;

public class CheckoutLine {
	
	private SLL<ShoppingCart> checkout = new SLL<ShoppingCart>();
	
	public int getSize() {
		//TODO
	}
	
	public void addShoppingCart(ShoppingCart cart) {
		//TODO
	}
	
	public ShoppingCart getNextShoppingCart() {
		//TODO
	}
	
	public double processAll() {
		//TODO
	}
	
	public String toString() {
		//TODO
	}
}