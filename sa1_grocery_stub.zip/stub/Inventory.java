package groceryStub;

import basics.SLL.Node;

public class Inventory {

	private SLL<Item> inventory = new SLL<Item>();
	
	public int getSize() {
		//TODO
	}
	
	public Item getAt(int index) {
		//TODO
	}
	
	public double getPrice(String name) {
		//TODO
	}
	
	public void addItems(String name, int number) {
		//TODO
	}
	
	public void addNewItem(String name, double price, int count) {
		//TODO
	}
	
	public boolean isAvailable(String name) {
		//TODO
	}
	
	public void takeItems(String name, int number) {
		//TODO
	}
	
	public String toString() {
		//TOD
	}
}
