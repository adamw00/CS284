package groceryStub;

public class Item {
	
	public String name;
	public double price;
	public int count;
	
	public Item(String name, double price) {
		this.name = name;
		this.price = price;
		this.count = 0;
	}
	
	public String getName() {
		//TODO
	}
	
	public double getPrice() {
		//TODO
	}
	
	public int getCount() {
		//TODO
	}
	
	public void decrementCount() {
		//TODO
	}
	
	public void incrementCount() {
		//TODO
	}
}