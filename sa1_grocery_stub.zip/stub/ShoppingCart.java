package basics;

import basics.SLL.Node;

public class ShoppingCart {
	
	private SLL<Item> stack = new SLL<Item>();
	
	public int getSize() {
		//TODO
	}
	
	public Item getItem(int number) {
		//TODO
	}
	
	public void putItem(Item item, int number) {
		//TODO
	}
	
	public double checkout() {
		//TODO
	}
	
	public String toString() {
		//TODO
	}
}
